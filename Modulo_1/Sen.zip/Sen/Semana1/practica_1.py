person = {
    "name": "Alice",
    "age": 30,
    "city": "Medellín"
}


person["profession"] = "Engineer"
person["age"] = 31

print(f"Updated person: {person}")
print(f"\n {type(person['age'])}")

print(type(person))


# print(f"Keys: {person.keys()}")
# print(f"Values: {person.values()}")
# print(f"Items: {person.items()}")


print(18-4)
print( 4//3)
print(5%3)